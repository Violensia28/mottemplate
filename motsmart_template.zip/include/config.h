#pragma once

// Put your project-wide configuration macros here
#define PROJECT_NAME "mot-smart-firmware"
