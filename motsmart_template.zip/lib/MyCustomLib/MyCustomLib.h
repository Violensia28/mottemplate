#pragma once
#include <Arduino.h>

namespace MyCustomLib {
  void hello();
}
