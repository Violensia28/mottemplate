#include "MyCustomLib.h"

namespace MyCustomLib {
  void hello(){
    Serial.println("Hello from MyCustomLib!");
  }
}
